setwd("C:\\Users\\it24102069\\Desktop\\IT24102069\\Lab_04")

data1<-read.table("Exercise.txt",header=TRUE,sep = " ")
fix(data1)

str(data1)

boxplot(X1,main="Box plot for Sales_X1",outline=TRUE,outpch=8,horizontal=TRUE)


summary(X1)


IQR(X1)


find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


outliers_years <- find_outliers(data1$X4)
print(outliers_years)




