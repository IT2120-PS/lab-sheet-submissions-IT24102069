setwd("C:\\Users\\user\\OneDrive\\Desktop\\IT24102069")

punif(10,min = 0 , max = 30 , lower.tail = TRUE)

1 - punif(20,min = 0 , max = 30 , lower.tail = TRUE)


punif(20,min = 0 , max = 30 , lower.tail = FALSE)


pexp(3,rate = 0.5,lower.tail = TRUE)

1 - pexp(4,rate = 0.5,lower.tail = TRUE)

pexp(4,rate = 0.5,lower.tail = FALSE)


1 - pnorm(37.9,mean = 36.8,sd = 0.4,lower.tail = TRUE)

pnorm(36.9,mean = 36.8 , sd = 0.4 , lower.tail = TRUE) - pnorm(36.4,mean = 36.8, sd = 0.4,lower.tail = TRUE)

qnorm(0.012,mean = 36.8 , sd = 0.4 , lower.tail = TRUE)

qnorm(0.01,mean= 36.8,sd=0.4,lower.tail = FALSE)
