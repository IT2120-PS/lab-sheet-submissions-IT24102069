setwd("C:\\Users\\user\\OneDrive\\Desktop\\IT24102069")

baking_times <- rnorm(25, mean=45, sd=2)
baking_times


t.test(baking_times, mu=46, alternative="less")
