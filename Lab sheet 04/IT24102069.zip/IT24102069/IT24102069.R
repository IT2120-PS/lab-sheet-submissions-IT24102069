setwd("C:\\Users\\user\\OneDrive\\Desktop\\IT24102069")
getwd()

branch_data <- read.csv("Exercise.txt", header = TRUE)

str(branch_data)

boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        outline = TRUE,
        outpch=8,
        horizontal = TRUE)

summary(branch_data$Advertising_X2)
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers: ", paste(sort(z[z < lb | z > ub]), collapse = ", ")))
}

get.outliers(branch_data$Years_X3)
